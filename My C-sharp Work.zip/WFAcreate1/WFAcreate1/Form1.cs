﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace WFAcreate1
{
    public partial class Form1 : Form
    {
       string sql { get; set; }

        DataAccess da { get; set; }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (this.txtUserName.Text == "" || this.txtPassword.Text == "")
            {
                MessageBox.Show("Enter the Username and Password");
            }
            else 
            {
                if (this.cmbRole.SelectedItem.ToString() == "admin")
                {
                    if (this.txtUserName.Text == "admin" || this.txtPassword.Text == "admin")
                    {
                        NewAccountPage cna = new NewAccountPage();
                        cna.Show();
                        this.Hide();

                    }
                    else 
                    {
                        MessageBox.Show("If you are the admin,please enter correct username and password");
                    }

                }
               // else if(this.cmbRole.SelectedItem.ToString() == "user")
                //{
                    //if (this.txtUserName.Text == "" || this.txtPassword.Text == "admin") 
                   // {

                   // }
               // }
            }
            
        }

        private void btnCreateNewAccount_Click(object sender, EventArgs e)
        {
            // NewAccountPage cna = new NewAccountPage();
            // cna.Show();
            this.pnlNewAccountCreate.Visible = false;
            this.pnlNewAccountCreate.Show();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.txtUserName.Text = "";
            this.txtPassword.Text = "";
        }
    }
}
