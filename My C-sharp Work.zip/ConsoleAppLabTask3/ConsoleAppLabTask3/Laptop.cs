﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppLabTask3
{
    internal class Laptop : Product
    {

    }
}
