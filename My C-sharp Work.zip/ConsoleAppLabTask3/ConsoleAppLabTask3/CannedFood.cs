﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppLabTask3
{
    internal class CannedFood : Product
    {
        internal override string quantity
        {
            set
            {
                base.Id = value + "s";
            }
        }
        internal CannedFood(experiryDate) : base(byte id, int quantity, double price, OurDate productiondate, string manufactureName)
        {
            this.date = Date;
        }

        internal override void ShowInfo()
        {
            base.ShowInfo();
            Console.WriteLine("quantity: {0}\n", this.quantity);
        }
    }
    
       

}

