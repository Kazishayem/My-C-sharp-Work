﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppLabTask3
{
    struct OurDate
    {
        public ushort day;
        public string month;
        public ushort year;

        public OurDate(ushort day, string month, ushort year)
        {
            this.day = day;
            this.month = month;
            this.year = year;

        }
        public void ShowDate()
        {
            Console.WriteLine("production date");
            Console.WriteLine("Day: {0}", this.day);
            Console.WriteLine("Month: {0}", this.month);
            Console.WriteLine("Year: {0}", this.year);
        }
    }

    struct manufacturerName
    {
        public string Name;

        public manufacturerName(str1ing Name)
        {
            this.Name = Name;
        }
        public void ShowName()
        {
            Console.WriteLine("manufacturer Name");
            Console.WriteLine("Day: {0}", this.Name);
        }
    }
    class Product
    {
        private ushort productId;
        private double quantity;
        private ulong price;
        private OurDate productionDate;
        private manufacturerName manufacturerName;

        internal virtual ushort productId
        {
            get
            {
            return this.productId;
                  }
            set
            {
                this.productId = "P-" + value;
            }
        }
         internal virtual string manufacturerName
{
    get
    {
        return this.manufacturerName;
    }
    set
    { 
        this.manufacturerName = value;
    }
}
internal  OurDate productionDate
{
    get
    {
        return this.productionDate;
    }
    set 
    { 
        this.productionDate = value;
    }
}
internal virtual udouble quantity
{
    get
            {
        return this.quantity;
    }
    set
            {
        this.quantity = value;
    }
}

        internal virtual ulong price
        {
            get
            {
                return this.price;
            }
            set
            {
                this.price = value;
            }
        }

        internal virtual void ShowInfo()
        {
            Console.WriteLine("Information Product: ");
            Console.WriteLine("Product ID: {0}", this.productId);
            Console.WriteLine("Name: {0}", this.manufacturerName);
            Console.WriteLine("quantity: {0}", this.quantity);
            Console.WriteLine("price: {0}", this.price);
            Console.WriteLine("productionDate: {0}", this.productionDate);
        }



    }
}
