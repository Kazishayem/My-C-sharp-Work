﻿namespace WFApRAAAA
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnlLoad = new MetroFramework.Controls.MetroPanel();
            this.myProgress = new MetroFramework.Controls.MetroProgressBar();
            this.lblPSMS = new MetroFramework.Controls.MetroLabel();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.pnlLoad.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlLoad
            // 
            this.pnlLoad.Controls.Add(this.lblPSMS);
            this.pnlLoad.Controls.Add(this.myProgress);
            this.pnlLoad.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlLoad.HorizontalScrollbarBarColor = true;
            this.pnlLoad.HorizontalScrollbarHighlightOnWheel = false;
            this.pnlLoad.HorizontalScrollbarSize = 10;
            this.pnlLoad.Location = new System.Drawing.Point(23, 63);
            this.pnlLoad.Name = "pnlLoad";
            this.pnlLoad.Size = new System.Drawing.Size(464, 219);
            this.pnlLoad.TabIndex = 0;
            this.pnlLoad.VerticalScrollbarBarColor = true;
            this.pnlLoad.VerticalScrollbarHighlightOnWheel = false;
            this.pnlLoad.VerticalScrollbarSize = 10;
            this.pnlLoad.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlLoad_Paint);
            // 
            // myProgress
            // 
            this.myProgress.Location = new System.Drawing.Point(0, 208);
            this.myProgress.Name = "myProgress";
            this.myProgress.Size = new System.Drawing.Size(464, 10);
            this.myProgress.TabIndex = 2;
            this.myProgress.Click += new System.EventHandler(this.myProgress_Click);
            // 
            // lblPSMS
            // 
            this.lblPSMS.AutoSize = true;
            this.lblPSMS.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.lblPSMS.Location = new System.Drawing.Point(102, 15);
            this.lblPSMS.Name = "lblPSMS";
            this.lblPSMS.Size = new System.Drawing.Size(256, 25);
            this.lblPSMS.TabIndex = 3;
            this.lblPSMS.Text = "Pet Shelter Management System";
            // 
            // timer
            // 
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(510, 294);
            this.Controls.Add(this.pnlLoad);
            this.Name = "Dashboard";
            this.Text = "Dashboard";
            this.pnlLoad.ResumeLayout(false);
            this.pnlLoad.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel pnlLoad;
        private MetroFramework.Controls.MetroLabel lblPSMS;
        private MetroFramework.Controls.MetroProgressBar myProgress;
        private System.Windows.Forms.Timer timer;
    }
}