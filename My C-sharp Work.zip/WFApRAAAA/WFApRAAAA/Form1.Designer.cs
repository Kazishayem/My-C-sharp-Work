﻿namespace WFApRAAAA
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.btnColor = new MetroFramework.Controls.MetroButton();
            this.pnlColor = new MetroFramework.Controls.MetroPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.process1 = new System.Diagnostics.Process();
            this.metroProgressBar1 = new MetroFramework.Controls.MetroProgressBar();
            this.pnlColor.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(246, 271);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(75, 23);
            this.metroButton1.TabIndex = 0;
            this.metroButton1.Text = "metroButton1";
            this.metroButton1.UseSelectable = true;
            // 
            // btnColor
            // 
            this.btnColor.Location = new System.Drawing.Point(48, 54);
            this.btnColor.Name = "btnColor";
            this.btnColor.Size = new System.Drawing.Size(75, 23);
            this.btnColor.TabIndex = 1;
            this.btnColor.Text = "Color";
            this.btnColor.UseSelectable = true;
            this.btnColor.Click += new System.EventHandler(this.btnColor_Click);
            this.btnColor.MouseLeave += new System.EventHandler(this.btnColor_MouseLeave);
            this.btnColor.MouseHover += new System.EventHandler(this.btnColor_MouseHover);
            // 
            // pnlColor
            // 
            this.pnlColor.Controls.Add(this.btnColor);
            this.pnlColor.HorizontalScrollbarBarColor = true;
            this.pnlColor.HorizontalScrollbarHighlightOnWheel = false;
            this.pnlColor.HorizontalScrollbarSize = 10;
            this.pnlColor.Location = new System.Drawing.Point(85, 63);
            this.pnlColor.Name = "pnlColor";
            this.pnlColor.Size = new System.Drawing.Size(176, 147);
            this.pnlColor.TabIndex = 2;
            this.pnlColor.VerticalScrollbarBarColor = true;
            this.pnlColor.VerticalScrollbarHighlightOnWheel = false;
            this.pnlColor.VerticalScrollbarSize = 10;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.metroProgressBar1);
            this.panel1.Location = new System.Drawing.Point(291, 63);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(272, 147);
            this.panel1.TabIndex = 3;
            // 
            // process1
            // 
            this.process1.StartInfo.Domain = "";
            this.process1.StartInfo.LoadUserProfile = false;
            this.process1.StartInfo.Password = null;
            this.process1.StartInfo.StandardErrorEncoding = null;
            this.process1.StartInfo.StandardOutputEncoding = null;
            this.process1.StartInfo.UserName = "";
            this.process1.SynchronizingObject = this;
            // 
            // metroProgressBar1
            // 
            this.metroProgressBar1.Location = new System.Drawing.Point(3, 137);
            this.metroProgressBar1.Name = "metroProgressBar1";
            this.metroProgressBar1.Size = new System.Drawing.Size(272, 10);
            this.metroProgressBar1.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(586, 364);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnlColor);
            this.Controls.Add(this.metroButton1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.pnlColor.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroButton metroButton1;
        private MetroFramework.Controls.MetroButton btnColor;
        private MetroFramework.Controls.MetroPanel pnlColor;
        private System.Windows.Forms.Panel panel1;
        private MetroFramework.Controls.MetroProgressBar metroProgressBar1;
        private System.Diagnostics.Process process1;
    }
}

