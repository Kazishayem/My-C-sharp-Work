﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace WFApRAAAA
{
    public partial class Dashboard : MetroForm
    {
        public Dashboard()
        {
            InitializeComponent();
        }
        int startpoint = 0;
        private void timer_Tick(object sender, EventArgs e)
        {
            startpoint += 1;
            myProgress.Value = startpoint;
            if (myProgress.Value ==100) 
            {
                myProgress.Value = 0;
                timer.Stop();
                Form1 log = new Form1();
                this.Hide();
                log.Show();
            }
        }

        private void myProgress_Click(object sender, EventArgs e)
        {
            //timer.Start();
        }

        private void pnlLoad_Paint(object sender, PaintEventArgs e)
        {
            timer.Start();
        }
    }
}
