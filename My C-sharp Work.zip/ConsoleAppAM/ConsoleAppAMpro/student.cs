﻿ using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppAMpro
{
    class student
    {
        public int a;
        private int b;
        protected int c;
        internal int d;
        protected internal int e;

    }
}
  