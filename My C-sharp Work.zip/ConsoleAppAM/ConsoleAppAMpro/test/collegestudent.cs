﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppAMpro.test
{
    class collegestudent
    {
    }
}
