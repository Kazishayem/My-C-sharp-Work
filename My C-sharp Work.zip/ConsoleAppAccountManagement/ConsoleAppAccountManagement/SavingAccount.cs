﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppAccountManagement
{
    internal class SavingAccount : Account
    {
        internal override string Id
        {
            //get { return this.id; }
            set { base.Id = "S" +value ; }
        }

        internal SavingAccount(string name,  OurDate date, OurAddress address, double balance) : base( name,date, address, balance)
        {
            
        }

        internal override void ShowInfo()
        {
            base.ShowInfo();
            //Console.WriteLine("Id: {0}\n", this.Id);
        }
    }
}
    

