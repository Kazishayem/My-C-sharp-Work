﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppAccountManagement
{
    internal struct OurAddress
    {
        public byte houseNo;
        public byte RoadNo;
        public string District;
        public string Country;


        public OurAddress(byte houseNo, byte RoadNo, string district, string Country)
        {
            this.houseNo = houseNo;
            this.RoadNo = RoadNo;
            this.Country = Country;
            this.District = district;
        }
        public void ShowAddress()
        {
            Console.WriteLine("Address Info");
            Console.WriteLine("House No: {0}", this.houseNo);
            Console.WriteLine("Road No: {0}", this.RoadNo);
            Console.WriteLine("District Name: {0}", this.District);
            Console.WriteLine("Country Name: {0}", this.Country);
            

        }

        
    }
   internal struct OurDate
    {
        public ushort day;
        public string month;
        public ushort year;
    
        public OurDate(ushort day, string month, ushort year)
        {
            this.day = day;
            this.month = month;
            this.year = year;
        }

        public void ShowDate()
        {
            Console.WriteLine("Opening Date");
            Console.WriteLine("Day: {0}", this.day);
            Console.WriteLine("Month: {0}", this.month);
            Console.WriteLine("Year: {0}", this.year);

        }

    }
    internal class Account
    {
        private string name;
        private static int serialNo  = 0;
        private string id;
        private OurDate date;
        private OurAddress address;
        private double balance;
    
        internal string  Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        internal virtual string Id
        {
            get { return this.id; }
            set { this.id = "A-" + value;}
        }

        internal OurDate Date

        {
            get { return this.date; }
            set { this.date = value; }
        }

        internal  OurAddress Address
        {
            get { return this.address; }
            set { this.address = value; }
        }
        internal double Balance
        {
            get { return this.balance; }
            set { this.balance = value; }
        }

        internal Account(string name,  OurDate date, OurAddress address, double balance)
        {
            this.Name = name; 
            this.Id = (++serialNo).ToString();
            this.Date = date;
            this.Address = address;
            this.Balance = balance;

        }

        internal virtual void ShowInfo()
        {
            Console.WriteLine("ID: {0}", this.Id);
            Console.WriteLine(" Name: {0}", this.Name);
            Console.WriteLine("Balance : {0}", this.Balance);
            this.Address.ShowAddress();
            this.Date.ShowDate();

        }

        
        

    }
}
