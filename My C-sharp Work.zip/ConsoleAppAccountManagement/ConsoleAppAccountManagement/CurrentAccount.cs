﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppAccountManagement
{
    internal class CurrentAccount : Account
    {
        internal override string Id
        {
           
            set { base.Id = "C" + value; }
        }

        internal CurrentAccount(string name, OurDate date, OurAddress address, double balance) : base(name, date, address, balance)
        {
            
        }

        internal override void ShowInfo()
        {
            base.ShowInfo();
            Console.WriteLine("Id: {0}\n", this.Id);
        }
    }
}
