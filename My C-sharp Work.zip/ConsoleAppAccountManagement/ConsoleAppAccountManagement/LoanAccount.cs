﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppAccountManagement
{
    class LoanAccount : Account
    {
        internal override string Id
        {
            
            set { base.Id = "L" + value; }
        }

        internal LoanAccount(string name, OurDate date, OurAddress address, double balance) : base(name, date, address, balance)
        {
            
        }

        internal override void ShowInfo()
        {
            base.ShowInfo();
            Console.WriteLine("Id: {0}\n", this.Id);
        }
    }
}
