﻿using System;

namespace ConsoleAppAccountManagement
{
    class Program
    {
        static void Main(string[] args)
        {
            Account   a1 = new SavingAccount("Kazi", new OurDate(2, "May", 1999), new OurAddress(10, 20, "Chittagong", "Wakanda"), 30000);
            Account a2 = new LoanAccount("Gazi", new OurDate(12, "June", 1997), new OurAddress(10, 20, "Dhaka", "Ugaanda"), 20000);
            Account a3 = new CurrentAccount("Mir", new OurDate(12, "June", 1997), new OurAddress(10, 20, "Kulna", "Hogwarts"), 10000);

            a1.ShowInfo();
            a2.ShowInfo();
            a3.ShowInfo();
        }

    }
}
    

