﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppLT
{

       internal class Member
    {
        public string name;
        public string address;

        internal string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }
        internal string Address
        {
            get { return this.address; }
            set { this.address = value; }
        }

        internal Member(string name, string address)
        {
            this.name = name;
            this.address = address;
        }

        internal virtual void ShowInfo()
        {
            Console.WriteLine("Information: ");
            Console.WriteLine("Name: {0}", this.Name);
            Console.WriteLine("Address: {0}", this.Address);

        }

    }

}
