﻿using System;

namespace ConsoleAppLT
{
    class Program
    {
        static void Main(string[] args)
        {
            Executive e = new Executive( "Secretary");

            Regular r = new Regular(" true");
        }
    }
}
