﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppLT
{
    internal class Regular
    {
        public string boolean;

        internal string Boolean
        {
            get { return this.boolean; }
            set { this.boolean = value; }
        }
        internal Regular(string boolean)
        {
            this.boolean = boolean;
        }

        internal virtual void ShowInfo()
        {
            Console.WriteLine("Information: ");
            Console.WriteLine("boolean: {0}", this.boolean);


        }
    }
}
