﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppLT
{
    internal class Executive
    {
        public string position;

        
        internal string Position
        {
            get { return this.position; }
            set { this.position = value; }
        }

        internal Executive(string position)
        {
            this.position = position;
        }
        internal virtual void ShowInfo()
        {
            Console.WriteLine("Information: ");
            Console.WriteLine("Position: {0}", this.position);
           

        }
    }

}
