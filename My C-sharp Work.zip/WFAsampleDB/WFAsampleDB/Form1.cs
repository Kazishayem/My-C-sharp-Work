﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace WFAsampleDB
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnClick_Click(object sender, EventArgs e)
        {
            string query = @"select * from login  where id ='" + this.txtID.Text + "'  and " +
                                    "password = '"+this.txtPassword.Text+"';";






            //"select * from login;";

            SqlConnection sqlcon = new SqlConnection(@"Data Source=CYBERSPACE\SQLEXPRESS;
                        Initial Catalog=vfalldb;Persist Security Info=True;User ID=sa;Password=kazishayem1234");

            sqlcon.Open();

            SqlCommand sqlcmd = new SqlCommand(query, sqlcon);

            SqlDataAdapter sda = new SqlDataAdapter(sqlcmd);

            DataSet ds = new DataSet();
            sda.Fill(ds);

            //this.lblID.Text = ds.Tables[0].Rows[0][0].ToString();
            //this.lblName.Text = ds.Tables[0].Rows[0][1].ToString();


            /*int count = 0;
            while (count < ds.Tables[0].Rows.Count) 
            {
                if (this.txtID.Text == ds.Tables[0].Rows[count][0].ToString() && this.txtPassword.Text==ds.Tables[0].Rows[count][2].ToString()) 
                {
                    MessageBox.Show("Valid");
                    break;
                }

            } */

            if(ds.Tables[0].Rows.Count == 1)
                MessageBox.Show("Valid");
            else
                MessageBox.Show("Invalid");

        } 
    }
}
