﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace wfaLogin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = @"select * from mylogin
                           where username = '" + this.txtUserName.Text + @"'
                           and password = '" + this.txtPassword.Text + "';";

                SqlConnection sqlcon = new SqlConnection(@"Data Source=CYBERSPACE\SQLEXPRESS;Initial Catalog=mylogin;
                                  Persist Security Info=True;User ID=sa;Password=kazishayem1234");
                sqlcon.Open();

                SqlCommand sqlcom = new SqlCommand(sql, sqlcon);

                SqlDataAdapter sda = new SqlDataAdapter(sqlcom);

                DataSet ds = new DataSet();
                sda.Fill(ds);

                this.lblUserName.Text = ds.Tables[0].Rows[0][0].ToString();
                this.lblPassword.Text = ds.Tables[0].Rows[0][0].ToString();


                int count = 0;
                while (count < ds.Tables[0].Rows.Count)
                {
                    if (this.txtUserName.Text == ds.Tables[0].Rows[0][0].ToString()
                        || this.txtPassword.Text == ds.Tables[0].Rows[0][0].ToString())
                    {
                        MessageBox.Show("login successfull");
                    }
                    //else { MessageBox.Show("login unsuccessfull"); }
                }
            }
            catch (Exception exc) 
            {
                MessageBox.Show("Enter the correct username or password"+exc.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.txtUserName.Text = "";
            this.txtPassword.Text = "";
        }
    }
}
