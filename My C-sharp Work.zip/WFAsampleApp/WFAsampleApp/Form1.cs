﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace WFAsampleApp
{
    public partial class Form1 : Form
    {
        internal DataAccess da { get; set; }
        internal DataSet ds { get; set; }
        public Form1()
        {
            InitializeComponent();
            this.da =new DataAccess();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string sql = @"select * from login  where id= '"+this.txtID.Text+"' and password = '"
                                             +this.txtPassword.Text+"';";

            this.ds =this.da.ExecuteQuery(sql);

            if (this.ds.Tables[0].Rows.Count == 1)
            {
                MessageBox.Show("Login successful");
                FormMovie log = new FormMovie();
                this.Hide();
                log.Show();
            }
            else
            {
                MessageBox.Show("Login unsuccessful");
            }

        }
    }
}
