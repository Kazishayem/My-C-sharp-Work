﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace WFAsampleApp
{
    public partial class FormMovie : Form
    {
        internal DataAccess da { get; set; }

        internal DataSet ds { get; set; }

        internal string sql { get; set; }

        internal DataTable dt { get; set; }

        public FormMovie()
        {
            InitializeComponent();
            this.da = new DataAccess();
            this.PopularGridView();

        }

        private void btnShowDetails_Click(object sender, EventArgs e)
        {
          
            this.PopularGridView();
        }

        private void PopularGridView(string sql = @"select * from movie;")
        {
            this.ds = this.da.ExecuteQuery(sql);

            this.dgvMovie.AutoGenerateColumns = false;
            this.dgvMovie.DataSource = this.ds.Tables[0];
        }



        private void btnSearch_Click(object sender, EventArgs e)
        {
            this.sql = @"select *  from movie  where genre = '"+this.txtSearch.Text+"';";
            this.PopularGridView(this.sql);
        }

        private void txtAutoSearch_TextChanged(object sender, EventArgs e)
        {
            this.sql = @"select * from movie  where title like '"+this.txtAutoSearch.Text +"%';";
            this.PopularGridView(this.sql);
        }


       //private bool InValidToSave()
      // {
           // if (string.IsNullOrEmpty(this.txtMovieID.Text) || string.IsNullOrEmpty(this.txtMovieName.Text) || string.IsNullOrEmpty(this.txtMovieIMDB.Text) || string.IsNullOrEmpty(this.txtMovieBO.Text) || string.IsNullOrEmpty(this.cmbMovieGen.Text)) 
          // {

          // }
     //   }
        private void btnMovieSave_Click(object sender, EventArgs e)
        {
            try
            {
                this.sql = @"insert into movie
                            values('" + this.txtMovieID.Text + "','" + this.txtMovieName.Text + "'," +
                           "" + this.txtMovieIMDB.Text + "," + this.txtMovieBO.Text + "," +
                           "'" + this.dtpMovieDate.Text + "','" + this.cmbMovieGen.Text + "');";



                int count = this.da.ExecuteUpdateQuery(this.sql);

                if (count == 1)
                    MessageBox.Show("Data insert secessfully");
                else
                    MessageBox.Show("Error while inserting data");

                this.PopularGridView();

            }
            catch (Exception exc)
            {
                MessageBox.Show("Error: "+ exc.Message);
            }


           
        }

        private void btnMovieDlt_Click(object sender, EventArgs e)
        {
            try 
            {
                var id = this.dgvMovie.CurrentRow.Cells[0].Value.ToString();
                var title = this.dgvMovie.CurrentRow.Cells["title"].Value.ToString();

                //MessageBox.Show(title);
                this.sql = @"delete from movie where id ='"+ id +"';";

                int count = this.da.ExecuteUpdateQuery(this.sql);

                if (count == 1)
                    MessageBox.Show("Movie the "+title+" has been deleted");
                else
                    MessageBox.Show("Error while deleting data");

                this.PopularGridView();

            }
            catch (Exception exc)
            {
                MessageBox.Show("Error: " + exc.Message);
            }

        }
        private void ClearData()
        {
            this.txtMovieBO.Text = "";
            this.AutoIdGenerate();
            this.txtMovieName.Text = "";
            this.txtMovieIMDB.Text = "";
            this.dtpMovieDate.Text = "";
            this.cmbMovieGen.Text = "";
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            this.ClearData();
            //this.AutoIdGenerate();
        }
        private void AutoIdGenerate()
        {
            this.sql = @"select id from movie order by id desc;";
            DataTable dt = this.da.ExecuteQueryTable(this.sql);
            string previousId = dt.Rows[0][0].ToString();
            string[] temp = previousId.Split('m');
            int serialNo = Convert.ToInt32(temp[1]);
            //MessageBox.Show();
            string newId = "m" + (++serialNo).ToString("000");
            this.txtMovieID.Text = newId;
        }
    }
}
