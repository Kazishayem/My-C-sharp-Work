﻿namespace WFAsampleApp
{
    partial class FormMovie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnMovieDlt = new System.Windows.Forms.Button();
            this.btnMovieSave = new System.Windows.Forms.Button();
            this.cmbMovieGen = new System.Windows.Forms.ComboBox();
            this.dtpMovieDate = new System.Windows.Forms.DateTimePicker();
            this.lblGen = new System.Windows.Forms.Label();
            this.lblRD = new System.Windows.Forms.Label();
            this.txtMovieBO = new System.Windows.Forms.TextBox();
            this.txtMovieIMDB = new System.Windows.Forms.TextBox();
            this.lblBOXo = new System.Windows.Forms.Label();
            this.lblIMDB = new System.Windows.Forms.Label();
            this.txtMovieName = new System.Windows.Forms.TextBox();
            this.txtMovieID = new System.Windows.Forms.TextBox();
            this.lblMname = new System.Windows.Forms.Label();
            this.lblMid = new System.Windows.Forms.Label();
            this.txtAutoSearch = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.dgvMovie = new System.Windows.Forms.DataGridView();
            this.btnShowDetails = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.title = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.imdbrating = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.income = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.releasedate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.genre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMovie)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnClear);
            this.panel1.Controls.Add(this.btnMovieDlt);
            this.panel1.Controls.Add(this.btnMovieSave);
            this.panel1.Controls.Add(this.cmbMovieGen);
            this.panel1.Controls.Add(this.dtpMovieDate);
            this.panel1.Controls.Add(this.lblGen);
            this.panel1.Controls.Add(this.lblRD);
            this.panel1.Controls.Add(this.txtMovieBO);
            this.panel1.Controls.Add(this.txtMovieIMDB);
            this.panel1.Controls.Add(this.lblBOXo);
            this.panel1.Controls.Add(this.lblIMDB);
            this.panel1.Controls.Add(this.txtMovieName);
            this.panel1.Controls.Add(this.txtMovieID);
            this.panel1.Controls.Add(this.lblMname);
            this.panel1.Controls.Add(this.lblMid);
            this.panel1.Controls.Add(this.txtAutoSearch);
            this.panel1.Controls.Add(this.btnSearch);
            this.panel1.Controls.Add(this.txtSearch);
            this.panel1.Controls.Add(this.dgvMovie);
            this.panel1.Controls.Add(this.btnShowDetails);
            this.panel1.Location = new System.Drawing.Point(19, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(631, 408);
            this.panel1.TabIndex = 0;
            // 
            // btnMovieDlt
            // 
            this.btnMovieDlt.Font = new System.Drawing.Font("Mongolian Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMovieDlt.Location = new System.Drawing.Point(184, 179);
            this.btnMovieDlt.Name = "btnMovieDlt";
            this.btnMovieDlt.Size = new System.Drawing.Size(75, 23);
            this.btnMovieDlt.TabIndex = 21;
            this.btnMovieDlt.Text = "Delete";
            this.btnMovieDlt.UseVisualStyleBackColor = true;
            this.btnMovieDlt.Click += new System.EventHandler(this.btnMovieDlt_Click);
            // 
            // btnMovieSave
            // 
            this.btnMovieSave.Font = new System.Drawing.Font("Mongolian Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMovieSave.Location = new System.Drawing.Point(18, 179);
            this.btnMovieSave.Name = "btnMovieSave";
            this.btnMovieSave.Size = new System.Drawing.Size(75, 23);
            this.btnMovieSave.TabIndex = 20;
            this.btnMovieSave.Text = "Save";
            this.btnMovieSave.UseVisualStyleBackColor = true;
            this.btnMovieSave.Click += new System.EventHandler(this.btnMovieSave_Click);
            // 
            // cmbMovieGen
            // 
            this.cmbMovieGen.FormattingEnabled = true;
            this.cmbMovieGen.Items.AddRange(new object[] {
            "action",
            "adventure",
            "drama",
            "comedy",
            "horror",
            "serial"});
            this.cmbMovieGen.Location = new System.Drawing.Point(90, 145);
            this.cmbMovieGen.Name = "cmbMovieGen";
            this.cmbMovieGen.Size = new System.Drawing.Size(129, 21);
            this.cmbMovieGen.TabIndex = 19;
            // 
            // dtpMovieDate
            // 
            this.dtpMovieDate.CustomFormat = "yyyy-MM-dd";
            this.dtpMovieDate.Font = new System.Drawing.Font("Mongolian Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpMovieDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpMovieDate.Location = new System.Drawing.Point(90, 115);
            this.dtpMovieDate.Name = "dtpMovieDate";
            this.dtpMovieDate.Size = new System.Drawing.Size(129, 21);
            this.dtpMovieDate.TabIndex = 18;
            // 
            // lblGen
            // 
            this.lblGen.AutoSize = true;
            this.lblGen.Font = new System.Drawing.Font("Mongolian Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGen.Location = new System.Drawing.Point(15, 145);
            this.lblGen.Name = "lblGen";
            this.lblGen.Size = new System.Drawing.Size(36, 13);
            this.lblGen.TabIndex = 15;
            this.lblGen.Text = "Genre";
            // 
            // lblRD
            // 
            this.lblRD.AutoSize = true;
            this.lblRD.Font = new System.Drawing.Font("Mongolian Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRD.Location = new System.Drawing.Point(17, 118);
            this.lblRD.Name = "lblRD";
            this.lblRD.Size = new System.Drawing.Size(68, 13);
            this.lblRD.TabIndex = 14;
            this.lblRD.Text = "Release Date";
            // 
            // txtMovieBO
            // 
            this.txtMovieBO.Location = new System.Drawing.Point(90, 89);
            this.txtMovieBO.Name = "txtMovieBO";
            this.txtMovieBO.Size = new System.Drawing.Size(129, 20);
            this.txtMovieBO.TabIndex = 13;
            // 
            // txtMovieIMDB
            // 
            this.txtMovieIMDB.Location = new System.Drawing.Point(90, 63);
            this.txtMovieIMDB.Name = "txtMovieIMDB";
            this.txtMovieIMDB.Size = new System.Drawing.Size(129, 20);
            this.txtMovieIMDB.TabIndex = 12;
            // 
            // lblBOXo
            // 
            this.lblBOXo.AutoSize = true;
            this.lblBOXo.Font = new System.Drawing.Font("Mongolian Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBOXo.Location = new System.Drawing.Point(15, 93);
            this.lblBOXo.Name = "lblBOXo";
            this.lblBOXo.Size = new System.Drawing.Size(57, 13);
            this.lblBOXo.TabIndex = 11;
            this.lblBOXo.Text = "Box office";
            // 
            // lblIMDB
            // 
            this.lblIMDB.AutoSize = true;
            this.lblIMDB.Font = new System.Drawing.Font("Mongolian Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIMDB.Location = new System.Drawing.Point(17, 66);
            this.lblIMDB.Name = "lblIMDB";
            this.lblIMDB.Size = new System.Drawing.Size(39, 13);
            this.lblIMDB.TabIndex = 10;
            this.lblIMDB.Text = "IMDB";
            // 
            // txtMovieName
            // 
            this.txtMovieName.Location = new System.Drawing.Point(90, 37);
            this.txtMovieName.Name = "txtMovieName";
            this.txtMovieName.Size = new System.Drawing.Size(129, 20);
            this.txtMovieName.TabIndex = 9;
            // 
            // txtMovieID
            // 
            this.txtMovieID.Location = new System.Drawing.Point(90, 11);
            this.txtMovieID.Name = "txtMovieID";
            this.txtMovieID.ReadOnly = true;
            this.txtMovieID.Size = new System.Drawing.Size(129, 20);
            this.txtMovieID.TabIndex = 8;
            // 
            // lblMname
            // 
            this.lblMname.AutoSize = true;
            this.lblMname.Font = new System.Drawing.Font("Mongolian Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMname.Location = new System.Drawing.Point(15, 41);
            this.lblMname.Name = "lblMname";
            this.lblMname.Size = new System.Drawing.Size(69, 13);
            this.lblMname.TabIndex = 7;
            this.lblMname.Text = "Movie Name";
            // 
            // lblMid
            // 
            this.lblMid.AutoSize = true;
            this.lblMid.Font = new System.Drawing.Font("Mongolian Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMid.Location = new System.Drawing.Point(17, 14);
            this.lblMid.Name = "lblMid";
            this.lblMid.Size = new System.Drawing.Size(54, 13);
            this.lblMid.TabIndex = 6;
            this.lblMid.Text = "Movie ID";
            // 
            // txtAutoSearch
            // 
            this.txtAutoSearch.Location = new System.Drawing.Point(409, 185);
            this.txtAutoSearch.Name = "txtAutoSearch";
            this.txtAutoSearch.Size = new System.Drawing.Size(100, 20);
            this.txtAutoSearch.TabIndex = 5;
            this.txtAutoSearch.TextChanged += new System.EventHandler(this.txtAutoSearch_TextChanged);
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Mongolian Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(545, 6);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 4;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(439, 7);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(100, 20);
            this.txtSearch.TabIndex = 3;
            // 
            // dgvMovie
            // 
            this.dgvMovie.AllowUserToAddRows = false;
            this.dgvMovie.AllowUserToDeleteRows = false;
            this.dgvMovie.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMovie.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.title,
            this.imdbrating,
            this.income,
            this.releasedate,
            this.genre});
            this.dgvMovie.Location = new System.Drawing.Point(0, 211);
            this.dgvMovie.Name = "dgvMovie";
            this.dgvMovie.ReadOnly = true;
            this.dgvMovie.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvMovie.Size = new System.Drawing.Size(628, 197);
            this.dgvMovie.TabIndex = 2;
            // 
            // btnShowDetails
            // 
            this.btnShowDetails.Font = new System.Drawing.Font("Mongolian Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowDetails.Location = new System.Drawing.Point(528, 182);
            this.btnShowDetails.Name = "btnShowDetails";
            this.btnShowDetails.Size = new System.Drawing.Size(103, 23);
            this.btnShowDetails.TabIndex = 1;
            this.btnShowDetails.Text = "Show Details >>";
            this.btnShowDetails.UseVisualStyleBackColor = true;
            this.btnShowDetails.Click += new System.EventHandler(this.btnShowDetails_Click);
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Mongolian Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(103, 178);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 22;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // id
            // 
            this.id.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.id.DataPropertyName = "id";
            this.id.HeaderText = "Movie ID";
            this.id.Name = "id";
            this.id.ReadOnly = true;
            // 
            // title
            // 
            this.title.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.title.DataPropertyName = "title";
            this.title.HeaderText = "Movie title";
            this.title.Name = "title";
            this.title.ReadOnly = true;
            // 
            // imdbrating
            // 
            this.imdbrating.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.imdbrating.DataPropertyName = "imdbrating";
            this.imdbrating.HeaderText = "IMDB";
            this.imdbrating.Name = "imdbrating";
            this.imdbrating.ReadOnly = true;
            // 
            // income
            // 
            this.income.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.income.DataPropertyName = "income";
            this.income.HeaderText = "Box office";
            this.income.Name = "income";
            this.income.ReadOnly = true;
            // 
            // releasedate
            // 
            this.releasedate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.releasedate.DataPropertyName = "releasedate";
            this.releasedate.HeaderText = "Release Date";
            this.releasedate.Name = "releasedate";
            this.releasedate.ReadOnly = true;
            // 
            // genre
            // 
            this.genre.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.genre.DataPropertyName = "genre";
            this.genre.HeaderText = "Genre";
            this.genre.Name = "genre";
            this.genre.ReadOnly = true;
            // 
            // FormMovie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(663, 432);
            this.Controls.Add(this.panel1);
            this.Name = "FormMovie";
            this.Text = "FormMovie";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMovie)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnShowDetails;
        private System.Windows.Forms.DataGridView dgvMovie;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.TextBox txtAutoSearch;
        private System.Windows.Forms.DateTimePicker dtpMovieDate;
        private System.Windows.Forms.Label lblGen;
        private System.Windows.Forms.Label lblRD;
        private System.Windows.Forms.TextBox txtMovieBO;
        private System.Windows.Forms.TextBox txtMovieIMDB;
        private System.Windows.Forms.Label lblBOXo;
        private System.Windows.Forms.Label lblIMDB;
        private System.Windows.Forms.TextBox txtMovieName;
        private System.Windows.Forms.TextBox txtMovieID;
        private System.Windows.Forms.Label lblMname;
        private System.Windows.Forms.Label lblMid;
        private System.Windows.Forms.Button btnMovieDlt;
        private System.Windows.Forms.Button btnMovieSave;
        private System.Windows.Forms.ComboBox cmbMovieGen;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn title;
        private System.Windows.Forms.DataGridViewTextBoxColumn imdbrating;
        private System.Windows.Forms.DataGridViewTextBoxColumn income;
        private System.Windows.Forms.DataGridViewTextBoxColumn releasedate;
        private System.Windows.Forms.DataGridViewTextBoxColumn genre;
    }
}