﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppModifiersPractice
{
    class test
    {
        public int Addition(int x,int y)
        {
            return x+y;
        }
        public void Addition(int x,string y)
        {
            
        }
        public void Addition(int x, int y, int z)
        {
            
        }
        public void Addition(int x, int y, int z,int w)
        {

        }
    }
}
