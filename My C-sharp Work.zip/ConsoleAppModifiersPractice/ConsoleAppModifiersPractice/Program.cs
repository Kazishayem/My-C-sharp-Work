﻿using System;

namespace ConsoleAppModifiersPractice
{
    class Program
    {
        static void Main(string[] args)
        {
            test t = new test();
            

        }
    }
}
