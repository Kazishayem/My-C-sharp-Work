﻿using System;

namespace ConsoleAppPractice
{
    class Program
    {
        static void Main(string[] args)
        {
            /*int ax = 50,bx = 60, cx = 150;
            string wx = "kazi";
            Console.WriteLine("Hello World!");
            Console.WriteLine("Hello my name is shayem!");
            Console.WriteLine("BYE");
            Console.WriteLine("ax={3},bx={1},cx={2},wx={0}",wx,bx,cx,ax);  //placeholder
            Console.WriteLine("wx ="+ wx + ",ax ="+ ax+ ",bx = "+ bx +", cx ="+ cx);*/

            string ax =Console.ReadLine();
            Console.WriteLine("output:{0}",ax);
            string bx = Console.ReadLine();
            Console.WriteLine("output:{0}", bx);

            int cx;
            string x = Console.ReadLine();
            cx = Convert.ToInt32(x);
            Console.WriteLine("{0}",cx);

        }
    }
}
 