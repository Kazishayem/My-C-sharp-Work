﻿using System;

namespace ClassLib
{
    public class Class1
    {
    }
}
