﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppAccountManagementSystem
{
    internal class CurrentAccount : Account
    {
        internal override string Id
        {

            set { base.Id = "C-123" + value; }
        }

        internal CurrentAccount(string name, OurDate date, OurAddress address, double balance) : base(name, date, address, balance)
        {

        }

        internal override void ShowInfo()
        {
            base.ShowInfo();
            Console.WriteLine("Id: {0}\n", this.Id);
        }
        internal override void deposit(double amount)
        {
            if (amount >= 500)
            {
                Console.WriteLine("Previous Balance: " ,this.Balance);
                Console.WriteLine("Deposit Amount: " + amount);
                this.Balance += amount;

                Console.WriteLine("Current Balance: " ,this.Balance);
            }
            else
            {
                Console.WriteLine("Can Not Deposit");
            }
        }
        internal override void withdraw(double amount)
        {
            if (amount > 0 && amount <= this.Balance && amount <= 5000)
            {
                Console.WriteLine("Previous Balance:	",this.Balance);
                Console.WriteLine("Withdraw Amount:	" ,+amount);
                this.Balance -= amount;

                Console.WriteLine("Current Balance: {0}", this.Balance);
            }
            else
            {
                Console.WriteLine("Can Not Withdraw");
            }
        }
        internal virtual void transfer(Account a, Account b, double amount)
        {
            if (amount > 0 && amount <= 2000)
            {
                Console.WriteLine("Previous Balance:	", this.Balance);
                Console.WriteLine("Transfer Amount:	" + amount);
                this.Balance = this.Balance - amount;
                a.Balance = a.Balance + amount;
                Console.WriteLine("Current Balance:	" + this.Balance);
            }
            else
            {
                Console.WriteLine("Can Not Transfer");
            }
        }
    }
}
