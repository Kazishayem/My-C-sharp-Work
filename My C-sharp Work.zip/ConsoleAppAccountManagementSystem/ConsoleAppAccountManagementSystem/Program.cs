﻿using System;

namespace ConsoleAppAccountManagementSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            Account a = new SavingAccount("Shayem", new OurDate(06, "Feb", 1999), new OurAddress(45, 12, "Chittagong", "Bangladesh"), 20000);
            Account b = new LoanAccount("Shayek", new OurDate(07, "March", 1995), new OurAddress(53, 20, "Dhaka", "Bangladesh"), 25000);
            Account c = new CurrentAccount("Shakib", new OurDate(11, "Dec", 2010), new OurAddress(1, 3, "Kulna", "Bangladesh"), 15000);

            a.ShowInfo();
            b.ShowInfo();
            c.ShowInfo();

            FinancialAccount.AddAccount(new SavingAccount("Shayem", new OurDate(06, "Feb", 1999), new OurAddress(45, 12, "Chittagong", "Bangladesh"), 20000));
            FinancialAccount.AddAccount(new LoanAccount("Shayek", new OurDate(07, "March", 1995), new OurAddress(53, 20, "Dhaka", "Bangladesh"), 25000));
            FinancialAccount.AddAccount(new CurrentAccount("Shakib", new OurDate(11, "Dec", 2010), new OurAddress(1, 3, "Kulna", "Bangladesh"), 15000));

            FinancialAccount.ShowAll();

        }
    }
}
