﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppAccountManagementSystem
{
    internal class SavingAccount : Account
    {
        internal override string Id
        {
            //get { return this.id; }
            set { base.Id = "S-334" + value; }
        }

        internal SavingAccount(string name, OurDate date, OurAddress address, double balance) : base(name, date, address, balance)
        {

        }

        internal override void ShowInfo()
        {
            base.ShowInfo();
           
        }
        internal override void deposit(double amount)
        {
            base.deposit(amount);
        }
        internal override void withdraw(double amount)
        {
            if (amount > 0 && amount <= this.Balance && amount <= 2000)
            {
                Console.WriteLine("Previous Balance:	" ,this.Balance);
                Console.WriteLine("Withdraw Amount:	" + amount);
                this.Balance -= amount;

                Console.WriteLine("Current Balance: {0}", this.Balance);
            }
            else
            {
                Console.WriteLine("Can Not Withdraw");
            }
        }
        internal virtual void transfer(Account a, Account b, double amount)
        {
            if (amount > 0 && amount <= 2000)
            {
                Console.WriteLine("Previous Balance:	" ,this.Balance);
                Console.WriteLine("Transfer Amount:	" + amount);
                this.Balance = this.Balance - amount;
                a.Balance = a.Balance + amount;
                Console.WriteLine("Current Balance:	" + this.Balance);
            }
            else
            {
                Console.WriteLine("Can Not Transfer");
            }
        }

    }

}
