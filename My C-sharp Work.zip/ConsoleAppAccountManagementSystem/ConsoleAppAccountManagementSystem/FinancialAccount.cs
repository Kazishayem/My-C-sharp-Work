﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppAccountManagementSystem
{
    internal static class FinancialAccount
    {
        private static Account[] accounts = new Account[1000];
        private static int count = 0;

        internal static void AddAccount(Account a)
        {
            accounts[count] = a;
            count++;
        }

        internal static void ShowAll()
        {
            int index = 0;
            while (index < count)
            {
                accounts[index].ShowInfo();
                index++;
            }
        }

        internal static bool SearchIndividualAccount(string key, out int i)
        {
            int index = 0;
            bool found = false;
            i = -1;
            while (index < count)
            {
                if (accounts[index].Id == key)
                {
                    Console.WriteLine("Account Found");
                    accounts[index].ShowInfo();
                    found = true;
                    i = index;
                    return found; //break;
                }
                index++;
            }
            if (!found)
                Console.WriteLine("Account Not found");

            return found;
        }

        internal static void DeleteAccount(string key)
        {
            int index;
            bool decision = SearchIndividualAccount(key, out index);
            string name = accounts[index].Name;
            if (decision)
            {
                accounts[index] = null;
                Console.WriteLine(name + " has been deleted.");
            }
        }

    }

}
