﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace WFAtimer
{
    public partial class Form2 : MetroForm
    {
        public Form2()
        {
            InitializeComponent();
        }
        int startpoint = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            startpoint += 5;
            myProgress1.Value = startpoint;
            if (myProgress1.Value == 100)
            {
                myProgress1.Value = 0;
                timer1.Stop();
                Deshboard log = new Deshboard();
                this.Hide();
                log.Show();
            }
        }
    }
}
