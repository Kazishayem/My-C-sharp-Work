﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace WFAtimer
{
    public partial class Deshboard : MetroForm
    {
        public Deshboard()
        {
            InitializeComponent();
        }
    }
}
