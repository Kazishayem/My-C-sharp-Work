﻿using System;

namespace ConsoleAppLabTask
{
    class Program
    {
        static void Main(string[] args)
        {
              Employee e = new Employee();
            e.SetemployeeId(123);
            e.SetName("kazi");
            e.monthlySalary(10000);

            Console.WriteLine("Employee ID: {0}", e.GetemployeeId());
            Console.WriteLine("Employee Name: {0}", e.GetName());
            Console.WriteLine("Employee salary: {0}", e.monthlySalary());

            joiningDate dateOne = new joiningDate(6, "february", 2020);
            e.Date(dateOne);

            Console.WriteLine("joining Date: {0}", e.Date());
            dateOne.ShowDate();

            Address addressOne = new OurAddress(45, "Kazi Shayem Mahamood", "Dhaka");
            e.Address(addressOne);

            Console.WriteLine("Address: {0}", e.Address());
            addressOne.ShowAddress();



        }
    }
}
