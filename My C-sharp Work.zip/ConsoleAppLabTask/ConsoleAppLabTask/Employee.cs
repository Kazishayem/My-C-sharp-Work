﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppLabTask
{
   
    struct Address
    {
        public int houseNo;
        public string streetName;
        public string upazillaName;

        public Address(int houseNo,string streetName,string upazillaName)
        {
            this.houseNo = houseNo;
            this.streetName = streetName;
            this.upazillaName = upazillaName;
        }
        public void ShowAddress()
        {
            Console.WriteLine("Address Info");
            Console.WriteLine("House No: {0}", this.houseNo);
            Console.WriteLine("Street Name: {0}", this.streetName);
            Console.WriteLine("Upazila Name: {0}", this.upazilaName);

        }

    }

    struct joiningDate
    {
        public int day;
        public string month;
        public int year;

        public joiningDate(int day, string month, int year)
        {
            this.day = day;
            this.month = month;
            this.year = year;
        }

        public void ShowDate()
        {
            Console.WriteLine("Joining Date");
            Console.WriteLine("Day: {0}", this.day);
            Console.WriteLine("Month: {0}", this.month);
            Console.WriteLine("Year: {0}", this.year);

        }

    }
    public class Employee
    {
        private int employeeId;
        private string name;
        private joiningDate Date;
        private double monthlySalary;
        private Address address;

       public int employeeId
        {
            set
            {
                if(employeeId<=300)
                {
                    this.employeeId = value;

                }
                else
                {
                    this.employeeId = 0;
                    Console.WriteLine("Out of Stock");
                }
            }
            get
            {
                return this.employeeId;
            }
        }

        public string Name
        {
            set 
            {
                this.name = value;

            }
            get
            { 
                return this.name;
            }
        }

        public double monthlySalary
        {
            set 
            { 
                this.monthlySalary = value;
            }
            get
            { 
                return this.monthlySalary;
            }
        }
        public joiningDate Date
        {
            set
            { 
                this.date = value;
            }
            get 
            { 
                return this.date; 
            }
        }
        public Address Address
        {
            set 
            { 
                this.address = value;
            }
            get
            { 
                return this.address; 
            }
        }

        public Employee(int id, string name, double monthlySalary, joiningDate date, Address address)
        {
            this.employeeId = id;
            this.Name = name;
            this.monthlySalary = monthlySalary;
            this.Date = date;
            this.address = address;

        }

        public void ShowInfo()
        {
            Console.WriteLine("Employee ID: {0}", this.employeeId);
            Console.WriteLine("Employee Name: {0}", this.Name);
            Console.WriteLine("Employee Monthly Salary: {0}", this.monthlySalary);
            this.address.ShowAddress();
            this.Date.ShowDate();

        }
    }
}
