﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFApractice
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void LABinformation_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            this.txtBoutputUN.Text = this.txtBusername.Text;
            this.lblPassword.Text = this.txtBpassword.Text;
            this.lblDepartment.Text = this.cmbDepartment.Text;
            this.lblDOB.Text = this.DTPicker.Text;
            if (this.rbBechelor.Checked)
            {
                this.lblProgram.Text = "Bechelor";

            }
            else if(this.rbMaster.Checked)
            {
                this.lblProgram.Text = this.rbMaster.Text;
            }
       
            else 
            {
                this.lblProgram.Text = this.rbOthers.Text;
            }

            this.pnlOutput.Visible = true;

        }


        private void btnClear_Click(object sender, EventArgs e)
        {
            this.txtBoutputUN.Text = "";
            this.lblPassword.Text = "NULL";
            this.lblDepartment.Text = "NULL";
            this.lblDOB.Text = "NULL";
            this.lblProgram.Text = "NULL";

            this.txtBusername.Text = "";
            this.txtBpassword.Text= "";
            //this.cmbDepartment.Text = "";
            this.cmbDepartment.SelectedIndex = -1;
            this.DTPicker.Text = "";
            this.rbBechelor.Checked = false;
            this.rbOthers.Checked = false;
            this.rbMaster.Checked = false;


            MessageBox.Show("All data cleared");

            this.pnlOutput.Visible = false;
        }
    }
}
