﻿namespace WFApractice
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PNLinformation = new System.Windows.Forms.Panel();
            this.PNprogram = new System.Windows.Forms.Panel();
            this.rbMaster = new System.Windows.Forms.RadioButton();
            this.rbBechelor = new System.Windows.Forms.RadioButton();
            this.txtProgram = new System.Windows.Forms.Label();
            this.btnShow = new System.Windows.Forms.Button();
            this.DTPicker = new System.Windows.Forms.DateTimePicker();
            this.txtDOB = new System.Windows.Forms.Label();
            this.cmbDepartment = new System.Windows.Forms.ComboBox();
            this.txtDepartment = new System.Windows.Forms.Label();
            this.txtBpassword = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.Label();
            this.txtBusername = new System.Windows.Forms.TextBox();
            this.txtUserName = new System.Windows.Forms.Label();
            this.LABinformation = new System.Windows.Forms.Label();
            this.pnlOutput = new System.Windows.Forms.Panel();
            this.lblProgram = new System.Windows.Forms.Label();
            this.lblDOB = new System.Windows.Forms.Label();
            this.lblDepartment = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBoutputUN = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtOutput = new System.Windows.Forms.Label();
            this.rbOthers = new System.Windows.Forms.RadioButton();
            this.PNLinformation.SuspendLayout();
            this.PNprogram.SuspendLayout();
            this.pnlOutput.SuspendLayout();
            this.SuspendLayout();
            // 
            // PNLinformation
            // 
            this.PNLinformation.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.PNLinformation.Controls.Add(this.PNprogram);
            this.PNLinformation.Controls.Add(this.txtProgram);
            this.PNLinformation.Controls.Add(this.btnShow);
            this.PNLinformation.Controls.Add(this.DTPicker);
            this.PNLinformation.Controls.Add(this.txtDOB);
            this.PNLinformation.Controls.Add(this.cmbDepartment);
            this.PNLinformation.Controls.Add(this.txtDepartment);
            this.PNLinformation.Controls.Add(this.txtBpassword);
            this.PNLinformation.Controls.Add(this.txtPassword);
            this.PNLinformation.Controls.Add(this.txtBusername);
            this.PNLinformation.Controls.Add(this.txtUserName);
            this.PNLinformation.Controls.Add(this.LABinformation);
            this.PNLinformation.Location = new System.Drawing.Point(62, 15);
            this.PNLinformation.Name = "PNLinformation";
            this.PNLinformation.Size = new System.Drawing.Size(312, 424);
            this.PNLinformation.TabIndex = 0;
            // 
            // PNprogram
            // 
            this.PNprogram.Controls.Add(this.rbOthers);
            this.PNprogram.Controls.Add(this.rbMaster);
            this.PNprogram.Controls.Add(this.rbBechelor);
            this.PNprogram.Location = new System.Drawing.Point(131, 214);
            this.PNprogram.Name = "PNprogram";
            this.PNprogram.Size = new System.Drawing.Size(132, 89);
            this.PNprogram.TabIndex = 12;
            // 
            // rbMaster
            // 
            this.rbMaster.AutoSize = true;
            this.rbMaster.Location = new System.Drawing.Point(30, 34);
            this.rbMaster.Name = "rbMaster";
            this.rbMaster.Size = new System.Drawing.Size(57, 17);
            this.rbMaster.TabIndex = 1;
            this.rbMaster.TabStop = true;
            this.rbMaster.Text = "Master";
            this.rbMaster.UseVisualStyleBackColor = true;
            // 
            // rbBechelor
            // 
            this.rbBechelor.AutoSize = true;
            this.rbBechelor.Location = new System.Drawing.Point(30, 11);
            this.rbBechelor.Name = "rbBechelor";
            this.rbBechelor.Size = new System.Drawing.Size(67, 17);
            this.rbBechelor.TabIndex = 0;
            this.rbBechelor.TabStop = true;
            this.rbBechelor.Text = "Bechelor";
            this.rbBechelor.UseVisualStyleBackColor = true;
            // 
            // txtProgram
            // 
            this.txtProgram.AutoSize = true;
            this.txtProgram.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProgram.Location = new System.Drawing.Point(46, 225);
            this.txtProgram.Name = "txtProgram";
            this.txtProgram.Size = new System.Drawing.Size(55, 15);
            this.txtProgram.TabIndex = 11;
            this.txtProgram.Text = "Program";
            // 
            // btnShow
            // 
            this.btnShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShow.Location = new System.Drawing.Point(105, 327);
            this.btnShow.Name = "btnShow";
            this.btnShow.Size = new System.Drawing.Size(75, 23);
            this.btnShow.TabIndex = 10;
            this.btnShow.Text = "Show";
            this.btnShow.UseVisualStyleBackColor = true;
            this.btnShow.Click += new System.EventHandler(this.btnShow_Click);
            // 
            // DTPicker
            // 
            this.DTPicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DTPicker.Location = new System.Drawing.Point(133, 177);
            this.DTPicker.Name = "DTPicker";
            this.DTPicker.Size = new System.Drawing.Size(154, 20);
            this.DTPicker.TabIndex = 8;
            this.DTPicker.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // txtDOB
            // 
            this.txtDOB.AutoSize = true;
            this.txtDOB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDOB.Location = new System.Drawing.Point(46, 182);
            this.txtDOB.Name = "txtDOB";
            this.txtDOB.Size = new System.Drawing.Size(76, 15);
            this.txtDOB.TabIndex = 7;
            this.txtDOB.Text = "Date Of Birth";
            // 
            // cmbDepartment
            // 
            this.cmbDepartment.FormattingEnabled = true;
            this.cmbDepartment.Items.AddRange(new object[] {
            "CSE",
            "EEE",
            "BBA"});
            this.cmbDepartment.Location = new System.Drawing.Point(133, 139);
            this.cmbDepartment.Name = "cmbDepartment";
            this.cmbDepartment.Size = new System.Drawing.Size(154, 21);
            this.cmbDepartment.TabIndex = 6;
            // 
            // txtDepartment
            // 
            this.txtDepartment.AutoSize = true;
            this.txtDepartment.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDepartment.Location = new System.Drawing.Point(46, 145);
            this.txtDepartment.Name = "txtDepartment";
            this.txtDepartment.Size = new System.Drawing.Size(72, 15);
            this.txtDepartment.TabIndex = 5;
            this.txtDepartment.Text = "Department";
            // 
            // txtBpassword
            // 
            this.txtBpassword.Location = new System.Drawing.Point(131, 100);
            this.txtBpassword.Name = "txtBpassword";
            this.txtBpassword.Size = new System.Drawing.Size(156, 20);
            this.txtBpassword.TabIndex = 4;
            this.txtBpassword.UseSystemPasswordChar = true;
            // 
            // txtPassword
            // 
            this.txtPassword.AutoSize = true;
            this.txtPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.Location = new System.Drawing.Point(46, 103);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(61, 15);
            this.txtPassword.TabIndex = 3;
            this.txtPassword.Text = "Password";
            // 
            // txtBusername
            // 
            this.txtBusername.Location = new System.Drawing.Point(131, 61);
            this.txtBusername.Name = "txtBusername";
            this.txtBusername.Size = new System.Drawing.Size(156, 20);
            this.txtBusername.TabIndex = 2;
            // 
            // txtUserName
            // 
            this.txtUserName.AutoSize = true;
            this.txtUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUserName.Location = new System.Drawing.Point(46, 64);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(67, 15);
            this.txtUserName.TabIndex = 1;
            this.txtUserName.Text = "UserName";
            // 
            // LABinformation
            // 
            this.LABinformation.AutoSize = true;
            this.LABinformation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LABinformation.Location = new System.Drawing.Point(101, 11);
            this.LABinformation.Name = "LABinformation";
            this.LABinformation.Size = new System.Drawing.Size(101, 20);
            this.LABinformation.TabIndex = 0;
            this.LABinformation.Text = "Information";
            this.LABinformation.Click += new System.EventHandler(this.LABinformation_Click);
            // 
            // pnlOutput
            // 
            this.pnlOutput.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pnlOutput.Controls.Add(this.lblProgram);
            this.pnlOutput.Controls.Add(this.lblDOB);
            this.pnlOutput.Controls.Add(this.lblDepartment);
            this.pnlOutput.Controls.Add(this.lblPassword);
            this.pnlOutput.Controls.Add(this.label1);
            this.pnlOutput.Controls.Add(this.label2);
            this.pnlOutput.Controls.Add(this.btnClear);
            this.pnlOutput.Controls.Add(this.label3);
            this.pnlOutput.Controls.Add(this.label4);
            this.pnlOutput.Controls.Add(this.txtBoutputUN);
            this.pnlOutput.Controls.Add(this.label5);
            this.pnlOutput.Controls.Add(this.txtOutput);
            this.pnlOutput.Location = new System.Drawing.Point(415, 15);
            this.pnlOutput.Name = "pnlOutput";
            this.pnlOutput.Size = new System.Drawing.Size(312, 424);
            this.pnlOutput.TabIndex = 1;
            this.pnlOutput.Visible = false;
            // 
            // lblProgram
            // 
            this.lblProgram.AutoSize = true;
            this.lblProgram.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProgram.Location = new System.Drawing.Point(130, 225);
            this.lblProgram.Name = "lblProgram";
            this.lblProgram.Size = new System.Drawing.Size(62, 15);
            this.lblProgram.TabIndex = 16;
            this.lblProgram.Text = "oProgram";
            // 
            // lblDOB
            // 
            this.lblDOB.AutoSize = true;
            this.lblDOB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDOB.Location = new System.Drawing.Point(130, 182);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(83, 15);
            this.lblDOB.TabIndex = 15;
            this.lblDOB.Text = "oDate Of Birth";
            // 
            // lblDepartment
            // 
            this.lblDepartment.AutoSize = true;
            this.lblDepartment.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDepartment.Location = new System.Drawing.Point(130, 145);
            this.lblDepartment.Name = "lblDepartment";
            this.lblDepartment.Size = new System.Drawing.Size(79, 15);
            this.lblDepartment.TabIndex = 14;
            this.lblDepartment.Text = "oDepartment";
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPassword.Location = new System.Drawing.Point(130, 105);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(68, 15);
            this.lblPassword.TabIndex = 13;
            this.lblPassword.Text = "oPassword";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(46, 225);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 15);
            this.label1.TabIndex = 12;
            this.label1.Text = "Program";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(46, 182);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 15);
            this.label2.TabIndex = 11;
            this.label2.Text = "Date Of Birth";
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(116, 328);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 10;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(46, 145);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "Department";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(46, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Password";
            // 
            // txtBoutputUN
            // 
            this.txtBoutputUN.Location = new System.Drawing.Point(131, 61);
            this.txtBoutputUN.Name = "txtBoutputUN";
            this.txtBoutputUN.ReadOnly = true;
            this.txtBoutputUN.Size = new System.Drawing.Size(154, 20);
            this.txtBoutputUN.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(46, 64);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 15);
            this.label5.TabIndex = 1;
            this.label5.Text = "UserName";
            // 
            // txtOutput
            // 
            this.txtOutput.AutoSize = true;
            this.txtOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOutput.Location = new System.Drawing.Point(129, 12);
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.Size = new System.Drawing.Size(64, 20);
            this.txtOutput.TabIndex = 0;
            this.txtOutput.Text = "Output";
            // 
            // rbOthers
            // 
            this.rbOthers.AutoSize = true;
            this.rbOthers.Location = new System.Drawing.Point(30, 57);
            this.rbOthers.Name = "rbOthers";
            this.rbOthers.Size = new System.Drawing.Size(56, 17);
            this.rbOthers.TabIndex = 2;
            this.rbOthers.TabStop = true;
            this.rbOthers.Text = "Others";
            this.rbOthers.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnlOutput);
            this.Controls.Add(this.PNLinformation);
            this.Name = "Form1";
            this.Text = "Form1";
            this.PNLinformation.ResumeLayout(false);
            this.PNLinformation.PerformLayout();
            this.PNprogram.ResumeLayout(false);
            this.PNprogram.PerformLayout();
            this.pnlOutput.ResumeLayout(false);
            this.pnlOutput.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PNLinformation;
        private System.Windows.Forms.Label LABinformation;
        private System.Windows.Forms.DateTimePicker DTPicker;
        private System.Windows.Forms.Label txtDOB;
        private System.Windows.Forms.ComboBox cmbDepartment;
        private System.Windows.Forms.Label txtDepartment;
        private System.Windows.Forms.TextBox txtBpassword;
        private System.Windows.Forms.Label txtPassword;
        private System.Windows.Forms.TextBox txtBusername;
        private System.Windows.Forms.Label txtUserName;
        private System.Windows.Forms.Button btnShow;
        private System.Windows.Forms.Panel pnlOutput;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtBoutputUN;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label txtOutput;
        private System.Windows.Forms.Panel PNprogram;
        private System.Windows.Forms.RadioButton rbMaster;
        private System.Windows.Forms.RadioButton rbBechelor;
        private System.Windows.Forms.Label txtProgram;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblProgram;
        private System.Windows.Forms.Label lblDOB;
        private System.Windows.Forms.Label lblDepartment;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.RadioButton rbOthers;
    }
}

