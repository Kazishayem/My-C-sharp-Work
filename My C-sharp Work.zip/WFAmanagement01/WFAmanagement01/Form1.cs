﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using MetroFramework.Forms;


namespace WFAmanagement01
{
    public partial class Form1 : MetroForm

 
    {
        internal DataAccess da { get; set; }
        internal string sql { get; set; }
        internal DataSet ds { get; set; }
        public Form1()
        {
            InitializeComponent();
                 this.da = new DataAccess();
           
           

        }

        private void btnInformation_Click(object sender, EventArgs e)
        {  
            
            //this.sql = @"select * from  information;";

            this.PopularGridView();
   
        }

        private void PopularGridView(string sql = @"select * from  information;") 
        {

            this.ds = this.da.ExecuteQuery(sql);
            this.dgvManagement.AutoGenerateColumns = false;

            this.dgvManagement.DataSource = this.ds.Tables[0];
        }

        private bool IsValidToSave()
        {
            if (String.IsNullOrEmpty(this.txtEmail.Text) || String.IsNullOrEmpty(this.txtUserName.Text)
                || String.IsNullOrEmpty(this.txtPassword.Text)
                || String.IsNullOrEmpty(this.txtPhoneNo.Text) || String.IsNullOrEmpty(this.txtAge.Text)
                || String.IsNullOrEmpty(this.cmbGender.Text))
            {
                return false;
            }
            else 
            {
                return true;
            }
        }

        private void btnADD_Click(object sender, EventArgs e)
        {
 
            try
            {

                if (this.IsValidToSave())
                {
                    DataTable dt = this.da.ExecuteQueryTable(@"select * from information where email = '" + this.txtEmail.Text + "'; ");

                    if (dt.Rows.Count == 1)
                    {
                        //update data
                        this.sql = @"update information
                                     set username = '"+this.txtUserName.Text+ @"',
                                     password = '"+this.txtPassword.Text+ @"',
                                     phoneno = '"+this.txtPhoneNo.Text+ @"',
                                     age = "+this.txtAge.Text+ @",
                                     gender = '"+this.cmbGender.Text+ @"'
                                     where email = '"+this.txtEmail.Text+"';";

                        int count = this.da.ExecuteUpdateQuery(this.sql);

                        if (count == 1)
                            MessageBox.Show("Member updated secessfully");
                        else
                            MessageBox.Show("Error while updating data");

                        //this.PopularGridView();

                    }
                    else if (dt.Rows.Count == 0)
                    {
                        //data insert

                        this.sql = @"insert into information
             values('" + this.txtEmail.Text + "','" + this.txtUserName.Text + "','" + this.txtPassword.Text + "'," +
        "'" + this.txtPhoneNo.Text + "'," + this.txtAge.Text + ",'" + this.cmbGender.Text + "');";

                        int count = this.da.ExecuteUpdateQuery(this.sql);

                        if (count == 1)
                            MessageBox.Show("Member added secessfully");
                        else
                            MessageBox.Show("Member added failed");

                        //this.PopularGridView();

                    }

                    this.PopularGridView();
                    this.ClearData();

                }
                else 
                {
                    MessageBox.Show("Please fill all the information");
                }
              
            }
            catch (Exception exc)
            {
                MessageBox.Show("Error :"+exc.Message);
            }

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                string username = this.dgvManagement.CurrentRow.Cells["username"].Value.ToString();

                this.sql = @"delete from information where username= '"+username+"';";

                int count = this.da.ExecuteUpdateQuery(this.sql);

                if (count == 1)
                    MessageBox.Show("Member  " + username + " has been deleted");
                else
                    MessageBox.Show("Error while deleting data");

                this.PopularGridView();
            }
            catch (Exception exc) 
            {
                MessageBox.Show("Error :" + exc.Message);
            }
        }

        private void dgvManagement_DoubleClick(object sender, EventArgs e)
        {
            this.txtEmail.Text = this.dgvManagement.CurrentRow.Cells["email"].Value.ToString();
            this.txtUserName.Text = this.dgvManagement.CurrentRow.Cells["username"].Value.ToString();
            this.txtPassword.Text = this.dgvManagement.CurrentRow.Cells["password"].Value.ToString();
            this.txtPhoneNo.Text = this.dgvManagement.CurrentRow.Cells["phoneno"].Value.ToString();
            this.txtAge.Text = this.dgvManagement.CurrentRow.Cells["age"].Value.ToString();
            this.cmbGender.Text = this.dgvManagement.CurrentRow.Cells["gender"].Value.ToString();

        }

        private void ClearData() 
        {
            this.txtEmail.Text = "";
            this.txtUserName.Text = "";
            this.txtPassword.Text = "";
            this.txtPhoneNo.Text = "";
            this.txtAge.Text = "";
            this.cmbGender.SelectedIndex = -1;

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
           // this.ClearData();

            AutoPasswordGenerate();
        }
        private void AutoPasswordGenerate() 
        {
            this.sql = "select password from information order by password desc;";
            DataTable dt = this.da.ExecuteQueryTable(this.sql);
            string previouspassword = dt.Rows[0][0].ToString();  
            string[] temp = previouspassword.Split('m');
            int SerialNo = Convert.ToInt32(temp[1]);
            MessageBox.Show(SerialNo.ToString());
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
