﻿namespace WFAmanagement01
{
    partial class login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLogin = new MetroFramework.Controls.MetroButton();
            this.lblLoginUserName = new MetroFramework.Controls.MetroLabel();
            this.lblPassword = new MetroFramework.Controls.MetroLabel();
            this.txtLoginUserName = new MetroFramework.Controls.MetroTextBox();
            this.txtLoginPassword = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.SuspendLayout();
            // 
            // btnLogin
            // 
            this.btnLogin.Location = new System.Drawing.Point(252, 195);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(75, 23);
            this.btnLogin.TabIndex = 0;
            this.btnLogin.Text = "Login";
            this.btnLogin.UseSelectable = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // lblLoginUserName
            // 
            this.lblLoginUserName.AutoSize = true;
            this.lblLoginUserName.Location = new System.Drawing.Point(155, 106);
            this.lblLoginUserName.Name = "lblLoginUserName";
            this.lblLoginUserName.Size = new System.Drawing.Size(71, 19);
            this.lblLoginUserName.TabIndex = 1;
            this.lblLoginUserName.Text = "UserName";
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new System.Drawing.Point(155, 143);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(63, 19);
            this.lblPassword.TabIndex = 2;
            this.lblPassword.Text = "Password";
            // 
            // txtLoginUserName
            // 
            // 
            // 
            // 
            this.txtLoginUserName.CustomButton.Image = null;
            this.txtLoginUserName.CustomButton.Location = new System.Drawing.Point(112, 1);
            this.txtLoginUserName.CustomButton.Name = "";
            this.txtLoginUserName.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtLoginUserName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtLoginUserName.CustomButton.TabIndex = 1;
            this.txtLoginUserName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtLoginUserName.CustomButton.UseSelectable = true;
            this.txtLoginUserName.CustomButton.Visible = false;
            this.txtLoginUserName.Lines = new string[0];
            this.txtLoginUserName.Location = new System.Drawing.Point(252, 106);
            this.txtLoginUserName.MaxLength = 32767;
            this.txtLoginUserName.Name = "txtLoginUserName";
            this.txtLoginUserName.PasswordChar = '\0';
            this.txtLoginUserName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtLoginUserName.SelectedText = "";
            this.txtLoginUserName.SelectionLength = 0;
            this.txtLoginUserName.SelectionStart = 0;
            this.txtLoginUserName.ShortcutsEnabled = true;
            this.txtLoginUserName.Size = new System.Drawing.Size(134, 23);
            this.txtLoginUserName.TabIndex = 3;
            this.txtLoginUserName.UseSelectable = true;
            this.txtLoginUserName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtLoginUserName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtLoginPassword
            // 
            // 
            // 
            // 
            this.txtLoginPassword.CustomButton.Image = null;
            this.txtLoginPassword.CustomButton.Location = new System.Drawing.Point(112, 1);
            this.txtLoginPassword.CustomButton.Name = "";
            this.txtLoginPassword.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtLoginPassword.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtLoginPassword.CustomButton.TabIndex = 1;
            this.txtLoginPassword.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtLoginPassword.CustomButton.UseSelectable = true;
            this.txtLoginPassword.CustomButton.Visible = false;
            this.txtLoginPassword.Lines = new string[0];
            this.txtLoginPassword.Location = new System.Drawing.Point(252, 139);
            this.txtLoginPassword.MaxLength = 32767;
            this.txtLoginPassword.Name = "txtLoginPassword";
            this.txtLoginPassword.PasswordChar = '\0';
            this.txtLoginPassword.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtLoginPassword.SelectedText = "";
            this.txtLoginPassword.SelectionLength = 0;
            this.txtLoginPassword.SelectionStart = 0;
            this.txtLoginPassword.ShortcutsEnabled = true;
            this.txtLoginPassword.Size = new System.Drawing.Size(134, 23);
            this.txtLoginPassword.TabIndex = 4;
            this.txtLoginPassword.UseSelectable = true;
            this.txtLoginPassword.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtLoginPassword.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel3.Location = new System.Drawing.Point(188, 43);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(62, 25);
            this.metroLabel3.TabIndex = 5;
            this.metroLabel3.Text = "LOGIN";
            // 
            // login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(451, 325);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.txtLoginPassword);
            this.Controls.Add(this.txtLoginUserName);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.lblLoginUserName);
            this.Controls.Add(this.btnLogin);
            this.DisplayHeader = false;
            this.Name = "login";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.Text = "login";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.login_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroButton btnLogin;
        private MetroFramework.Controls.MetroLabel lblLoginUserName;
        private MetroFramework.Controls.MetroLabel lblPassword;
        private MetroFramework.Controls.MetroTextBox txtLoginUserName;
        private MetroFramework.Controls.MetroTextBox txtLoginPassword;
        private MetroFramework.Controls.MetroLabel metroLabel3;
    }
}