﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace WindowsFormsApp2d33
{
    public partial class Form1 : MetroForm
    {
        public Form1()
        {
            InitializeComponent();
        }
        int Startpoint = 0;
        private void timer_Tick(object sender, EventArgs e)
        {
            Startpoint += 5;
            myProgress.Value = Startpoint;
            if (myProgress.Value == 100) 
            {
                myProgress.Value = 0;
                timer.Stop();
                Form2 log = new Form2();
                this.Hide();
                log.Show();
            
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer.Start();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
