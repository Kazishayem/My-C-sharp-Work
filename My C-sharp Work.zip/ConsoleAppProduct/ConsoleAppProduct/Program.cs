﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppProduct
{
    struct OurDate
    {
        public ushort day;
        public ushort month;
        public ushort year;

        public OurDate(ushort day, ushort month, ushort year)
        {
            this.day = day;
            this.month = month;
            this.year = year;
        }

        public void ShowDate()
        {
            Console.WriteLine("Day: {0}", this.day);
            Console.WriteLine("Month: {0}", this.month);
            Console.WriteLine("Year: {0}", this.year);

        }

    }
    class Product
    {
        private ushort id;
        private string name;
        private OurDate date;
        private double price;



        public void SetId(ushort id)
        {
            if (id >= 0 && id <= 10000)
            {
                this.id = id;

            }
            else
            {
                Console.WriteLine("Out of Stock");


            }

        }
        public ushort GetId()
        {

            return this.id;
        }

        public void SetName(String name)
        {
            this.name = name;
        }
        public string GetName()
        {
            return this.name;
        }
        public void SetPrice(double price)
        {
            if (price >= 0)
            {
                this.price = price;

            }
            else
            {
                Console.WriteLine("Price can not ne Negative");
            }
        }
        public double GetPrice()
        {
            return price;
        }

        public void SetDate(OurDate date)
        {
            this.date = date;
        }
        public OurDate GetDate()
        {
            return this.date;
        }
        public Product()
        {
            Console.Write("Insert ID: ");
            this.SetId(Convert.ToUInt16(Console.ReadLine()));
            Console.Write("Insert Name: ");
            this.SetName(Console.ReadLine());
            Console.Write("Insert CGPA: ");
            this.SetPrice(Convert.ToDouble(Console.ReadLine()));

        }

        public Product(ushort id, string name, double cgpa, string bloodGroup, OurDate date)
        {
            this.id = id;
            this.name = name;
            this.SetPrice(price);
            this.SetDate(date);
        }

        public void ShowProductInfo()
        {
            Console.WriteLine("Student ID: {0}", this.GetId());
            Console.WriteLine("Student Name: {0}", this.GetName());
            Console.WriteLine("Student Cgpa: {0}", this.GetPrice());
            this.date.ShowDate();

        }
    }
}