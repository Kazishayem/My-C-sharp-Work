﻿namespace WindowsFormsApp1
{
    partial class FormInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TB = new System.Windows.Forms.Panel();
            this.RBprogram = new System.Windows.Forms.Panel();
            this.RBmaster = new System.Windows.Forms.RadioButton();
            this.RbBachelor = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.DOBinfo = new System.Windows.Forms.DateTimePicker();
            this.ComboDepartment = new System.Windows.Forms.ComboBox();
            this.INPUTtype = new System.Windows.Forms.Label();
            this.INPUTdepartment = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.INPUTpassword = new System.Windows.Forms.Label();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.INPUTusername = new System.Windows.Forms.Label();
            this.heading = new System.Windows.Forms.Label();
            this.Bshow = new System.Windows.Forms.Button();
            this.TB.SuspendLayout();
            this.RBprogram.SuspendLayout();
            this.SuspendLayout();
            // 
            // TB
            // 
            this.TB.Controls.Add(this.Bshow);
            this.TB.Controls.Add(this.RBprogram);
            this.TB.Controls.Add(this.DOBinfo);
            this.TB.Controls.Add(this.ComboDepartment);
            this.TB.Controls.Add(this.INPUTtype);
            this.TB.Controls.Add(this.INPUTdepartment);
            this.TB.Controls.Add(this.txtPassword);
            this.TB.Controls.Add(this.INPUTpassword);
            this.TB.Controls.Add(this.txtUserName);
            this.TB.Controls.Add(this.INPUTusername);
            this.TB.Controls.Add(this.heading);
            this.TB.Location = new System.Drawing.Point(18, 16);
            this.TB.Name = "TB";
            this.TB.Size = new System.Drawing.Size(287, 426);
            this.TB.TabIndex = 0;
            // 
            // RBprogram
            // 
            this.RBprogram.Controls.Add(this.RBmaster);
            this.RBprogram.Controls.Add(this.RbBachelor);
            this.RBprogram.Controls.Add(this.label1);
            this.RBprogram.Location = new System.Drawing.Point(17, 246);
            this.RBprogram.Name = "RBprogram";
            this.RBprogram.Size = new System.Drawing.Size(229, 62);
            this.RBprogram.TabIndex = 20;
            // 
            // RBmaster
            // 
            this.RBmaster.AutoSize = true;
            this.RBmaster.Font = new System.Drawing.Font("MV Boli", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RBmaster.Location = new System.Drawing.Point(130, 36);
            this.RBmaster.Name = "RBmaster";
            this.RBmaster.Size = new System.Drawing.Size(62, 20);
            this.RBmaster.TabIndex = 14;
            this.RBmaster.TabStop = true;
            this.RBmaster.Text = "Master";
            this.RBmaster.UseVisualStyleBackColor = true;
            // 
            // RbBachelor
            // 
            this.RbBachelor.AutoSize = true;
            this.RbBachelor.Font = new System.Drawing.Font("MV Boli", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RbBachelor.Location = new System.Drawing.Point(130, 12);
            this.RbBachelor.Name = "RbBachelor";
            this.RbBachelor.Size = new System.Drawing.Size(68, 20);
            this.RbBachelor.TabIndex = 13;
            this.RbBachelor.TabStop = true;
            this.RbBachelor.Text = "Bachelor";
            this.RbBachelor.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MV Boli", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(14, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 17);
            this.label1.TabIndex = 9;
            this.label1.Text = "Program";
            // 
            // DOBinfo
            // 
            this.DOBinfo.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DOBinfo.Location = new System.Drawing.Point(123, 191);
            this.DOBinfo.Name = "DOBinfo";
            this.DOBinfo.Size = new System.Drawing.Size(123, 20);
            this.DOBinfo.TabIndex = 12;
            // 
            // ComboDepartment
            // 
            this.ComboDepartment.FormattingEnabled = true;
            this.ComboDepartment.Items.AddRange(new object[] {
            "CSE",
            "EEE",
            "BBA"});
            this.ComboDepartment.Location = new System.Drawing.Point(123, 153);
            this.ComboDepartment.Name = "ComboDepartment";
            this.ComboDepartment.Size = new System.Drawing.Size(121, 21);
            this.ComboDepartment.TabIndex = 11;
            // 
            // INPUTtype
            // 
            this.INPUTtype.AutoSize = true;
            this.INPUTtype.Font = new System.Drawing.Font("MV Boli", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.INPUTtype.Location = new System.Drawing.Point(8, 194);
            this.INPUTtype.Name = "INPUTtype";
            this.INPUTtype.Size = new System.Drawing.Size(93, 17);
            this.INPUTtype.TabIndex = 7;
            this.INPUTtype.Text = "Date Of Birth";
            // 
            // INPUTdepartment
            // 
            this.INPUTdepartment.AutoSize = true;
            this.INPUTdepartment.Font = new System.Drawing.Font("MV Boli", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.INPUTdepartment.Location = new System.Drawing.Point(28, 153);
            this.INPUTdepartment.Name = "INPUTdepartment";
            this.INPUTdepartment.Size = new System.Drawing.Size(80, 17);
            this.INPUTdepartment.TabIndex = 5;
            this.INPUTdepartment.Text = "Department";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(121, 110);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(123, 20);
            this.txtPassword.TabIndex = 4;
            this.txtPassword.UseSystemPasswordChar = true;
            this.txtPassword.TextChanged += new System.EventHandler(this.TBpasswordInput_TextChanged);
            // 
            // INPUTpassword
            // 
            this.INPUTpassword.AutoSize = true;
            this.INPUTpassword.Font = new System.Drawing.Font("MV Boli", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.INPUTpassword.Location = new System.Drawing.Point(28, 110);
            this.INPUTpassword.Name = "INPUTpassword";
            this.INPUTpassword.Size = new System.Drawing.Size(63, 17);
            this.INPUTpassword.TabIndex = 3;
            this.INPUTpassword.Text = "Password";
            this.INPUTpassword.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(121, 69);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(123, 20);
            this.txtUserName.TabIndex = 2;
            // 
            // INPUTusername
            // 
            this.INPUTusername.AutoSize = true;
            this.INPUTusername.Font = new System.Drawing.Font("MV Boli", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.INPUTusername.Location = new System.Drawing.Point(28, 69);
            this.INPUTusername.Name = "INPUTusername";
            this.INPUTusername.Size = new System.Drawing.Size(73, 17);
            this.INPUTusername.TabIndex = 1;
            this.INPUTusername.Text = "User Name";
            this.INPUTusername.Click += new System.EventHandler(this.label1_Click);
            // 
            // heading
            // 
            this.heading.AutoSize = true;
            this.heading.Font = new System.Drawing.Font("MV Boli", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.heading.Location = new System.Drawing.Point(76, 17);
            this.heading.Name = "heading";
            this.heading.Size = new System.Drawing.Size(116, 25);
            this.heading.TabIndex = 0;
            this.heading.Text = "Information";
            // 
            // Bshow
            // 
            this.Bshow.Font = new System.Drawing.Font("MV Boli", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bshow.Location = new System.Drawing.Point(91, 351);
            this.Bshow.Name = "Bshow";
            this.Bshow.Size = new System.Drawing.Size(75, 23);
            this.Bshow.TabIndex = 26;
            this.Bshow.Text = "Show";
            this.Bshow.UseVisualStyleBackColor = true;
            // 
            // FormInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(704, 461);
            this.Controls.Add(this.TB);
            this.Name = "FormInfo";
            this.Text = " ";
            this.TB.ResumeLayout(false);
            this.TB.PerformLayout();
            this.RBprogram.ResumeLayout(false);
            this.RBprogram.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel TB;
        private System.Windows.Forms.Label INPUTusername;
        private System.Windows.Forms.Label heading;
        private System.Windows.Forms.Label INPUTtype;
        private System.Windows.Forms.Label INPUTdepartment;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label INPUTpassword;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.ComboBox ComboDepartment;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker DOBinfo;
        private System.Windows.Forms.RadioButton RBmaster;
        private System.Windows.Forms.RadioButton RbBachelor;
        private System.Windows.Forms.Panel RBprogram;
        private System.Windows.Forms.Button Bshow;
    }
}