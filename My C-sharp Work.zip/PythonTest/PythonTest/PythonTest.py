'''
import os
print("kazi shayem mahamood")
from playsound import playsound
playsound('H:\\mmmmmmmmmmmmm\\songs\\best song\\[Songs.PK] Khwaja Mere Khwaja - Jodhaa Akbar (2008).mp3')

shayem
mahamood

# shayem

import os
print(os.listdir())
'''
'''
a= 'harry'
b=345
c= 34.454
d=None
e = True
A='shayem'
print(a)
print(A)
print(type(a))
print(type(b))
print(type(c))
print(type(d))
print(type(e))

'''
# a=3
# a -=6
# b=4
# print("the value of a+b is", a-b)
# b = (14!=7)
# print(b)

'''
TypeCasting

a= "3456"
a= int(a)
print(a+ 4)

'''
'''
a= input("Enter Your Name \n")
print(a)
'''
'''
a= input("Enter A Number: ")
a= int(a)
print(type(a))
'''
'''
a= input("Enter first Number: ")
b= input("Enter second Number: ")
a= int(a)
b= int(b)

avg = (a+b)/2
print("The Average of a and b is ",avg)
'''
'''
a= input("Enter a Number: ")
a= int(a)
print("The square of a number is",a*a)
'''

# Chapter 3 Start
# Concatenating two Strings
'''
greeting = "Good Morning, "
name = "Shayem"
a= greeting + name
print(a)
'''
'''
name = "Shayem"
print(name[0:3])
'''

'''
#string functions
story = "once upon a time there was a youtuber named harry who uploaded python course with notes"
print(len(story))
print(story.endswith("notes"))
print(story.count("a"))
print(story.capitalize())
print(story.find("was"))
print(story.replace("harry","shayem"))
'''
'''
#double space string

st= "this is a string of double  spaces"
doubleSpaces = st.find("  ")
print(doubleSpaces)

'''


