﻿namespace wfaPETTT
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnlLoad = new MetroFramework.Controls.MetroPanel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.myProgress = new MetroFramework.Controls.MetroProgressBar();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.mbtnStart = new MetroFramework.Controls.MetroButton();
            this.pnlLoad.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlLoad
            // 
            this.pnlLoad.Controls.Add(this.mbtnStart);
            this.pnlLoad.Controls.Add(this.myProgress);
            this.pnlLoad.Controls.Add(this.metroLabel1);
            this.pnlLoad.HorizontalScrollbarBarColor = true;
            this.pnlLoad.HorizontalScrollbarHighlightOnWheel = false;
            this.pnlLoad.HorizontalScrollbarSize = 10;
            this.pnlLoad.Location = new System.Drawing.Point(50, 63);
            this.pnlLoad.Name = "pnlLoad";
            this.pnlLoad.Size = new System.Drawing.Size(432, 250);
            this.pnlLoad.TabIndex = 0;
            this.pnlLoad.Theme = MetroFramework.MetroThemeStyle.Light;
            this.pnlLoad.VerticalScrollbarBarColor = true;
            this.pnlLoad.VerticalScrollbarHighlightOnWheel = false;
            this.pnlLoad.VerticalScrollbarSize = 10;
            this.pnlLoad.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlLoad_Paint);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.Location = new System.Drawing.Point(79, 112);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(267, 25);
            this.metroLabel1.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "Pet Shalter Management System";
            this.metroLabel1.Theme = MetroFramework.MetroThemeStyle.Light;
            // 
            // myProgress
            // 
            this.myProgress.Location = new System.Drawing.Point(0, 240);
            this.myProgress.Name = "myProgress";
            this.myProgress.Size = new System.Drawing.Size(432, 10);
            this.myProgress.TabIndex = 3;
            this.myProgress.Click += new System.EventHandler(this.myProgress_Click);
            // 
            // timer
            // 
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // mbtnStart
            // 
            this.mbtnStart.Location = new System.Drawing.Point(169, 156);
            this.mbtnStart.Name = "mbtnStart";
            this.mbtnStart.Size = new System.Drawing.Size(75, 23);
            this.mbtnStart.TabIndex = 4;
            this.mbtnStart.Text = "Start";
            this.mbtnStart.UseSelectable = true;
            this.mbtnStart.Click += new System.EventHandler(this.mbtnStart_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 336);
            this.Controls.Add(this.pnlLoad);
            this.Name = "Form1";
            this.Text = "Form1";
            this.pnlLoad.ResumeLayout(false);
            this.pnlLoad.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel pnlLoad;
        private MetroFramework.Controls.MetroProgressBar myProgress;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private System.Windows.Forms.Timer timer;
        private MetroFramework.Controls.MetroButton mbtnStart;
    }
}

